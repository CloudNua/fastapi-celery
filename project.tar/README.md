# fastapi-celery
Task Broker using FastAPI, Celery, Redis &amp; RabbitMQ
